read -p "Enter the Path of the SSH Key: " key_path
read -p "Enter the model directory Path(ex> ./models): " model_directory
read -p "Enter the models.config Path(ex) ./models/models.config): " model_config

while true; do
    read -p "Enter the UserName of the Worker node(If you want to quit, enter 0): " WORKER_USERNAME
    if [[ "$WORKER_USERNAME" == "0" ]]; then
        break
    fi
    read -p "Enter the Public IP Address of the Worker node: " WORKER_PUBLIC_IP

    ssh -i $key_path $WORKER_USERNAME@$WORKER_PUBLIC_IP "mkdir -p /home/$WORKER_USERNAME/models"
    ssh -i $key_path $WORKER_USERNAME@$WORKER_PUBLIC_IP "sudo chmod +w /home/$WORKER_USERNAME/models"
    scp -i $key_path $model_config $WORKER_USERNAME@$WORKER_PUBLIC_IP:/home/$WORKER_USERNAME/models
    scp -i $key_path -r $model_directory $WORKER_USERNAME@$WORKER_PUBLIC_IP:/home/$WORKER_USERNAME
done
