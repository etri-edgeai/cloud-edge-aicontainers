#!/bin/bash

# Get key(.pem) path for ssh communication
read -p "Enter the path of the aws ssh key : " ssh_key_path

# ip address and user name of the master node
read -p "Enter the k3s master public ip : " MASTER_IP
read -p "Enter the k3s master name : " MASTER_NAME
read -p "Enter the k3s master cluster name : " CLUSTER_NAME

# path default setting
kubeconfig_path="/tmp/$CLUSTER_NAME-kubeconfig.yaml"
inven_path="/tmp/$CLUSTER_NAME-inventory.ini"

# save to ./inventory.ini from user information
echo -e "[all:vars]" > "$inven_path"
echo -e "ansible_ssh_private_key_file=$ssh_key_path" >> "$inven_path"
echo -e "ansible_ssh_common_args='-o StrictHostKeyChecking=no'" >> "$inven_path"

echo -e "\n[master_node]" >> "$inven_path"
echo -e "master ansible_host=$MASTER_IP ansible_user=$MASTER_NAME" >> "$inven_path"

echo -e "\n[master_node:vars]" >> "$inven_path"
echo -e "master_cluster_name=$CLUSTER_NAME" >> "$inven_path"

# ansible-playbook 실행하여 cluster join하기
ansible-playbook -i "$inven_path" ansible_assets/k3s_cluster_init.yaml

# Accessing the cluster from outside with kubectl
mkdir -p $HOME/.kube
sudo cp "$kubeconfig_path" $HOME/.kube/$CLUSTER_NAME
sudo chown $(id -u):$(id -g) $HOME/.kube/$CLUSTER_NAME
sudo chmod 600 $HOME/.kube/$CLUSTER_NAME