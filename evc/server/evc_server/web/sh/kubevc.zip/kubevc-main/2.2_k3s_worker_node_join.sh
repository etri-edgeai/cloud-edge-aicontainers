#!/bin/bash

# Get key(.pem) path for ssh communication
read -p "Enter the path of the aws ssh key : " ssh_key_path
read -p "Enter the master private ip : " MASTER_PRIVATE_IP

# ip address and user name of the master node
read -p "Enter the master public ip : " MASTER_IP
read -p "Enter the master name : " MASTER_NAME

# ip address and user name of the worker node
read -p "Enter the worker public ip : " WORKER_IP
read -p "Enter the worker name : " WORKER_NAME

# path default setting
kubeconfig_path="/tmp/$WORKER_NAME-$WORKER_IP-kubeconfig.yaml"
inven_path="/tmp/$WORKER_NAME-$WORKER_IP-inventory.ini"

# save to ./inventory.ini from user information
echo -e "[all:vars]" > "$inven_path"
echo -e "ansible_ssh_private_key_file=$ssh_key_path" >> "$inven_path"
echo -e "ansible_ssh_common_args='-o StrictHostKeyChecking=no'" >> "$inven_path"

echo -e "\n[master_node]" >> "$inven_path"
echo -e "master ansible_host=$MASTER_IP ansible_user=$MASTER_NAME" >> "$inven_path"

echo -e "\n[worker_node]" >> "$inven_path"
echo -e "worker ansible_host=$WORKER_IP ansible_user=$WORKER_NAME" >> "$inven_path"

while true; do
	read -p "Do you want to add the worker node ip? [Y/N] : " answer

	if [ "$answer" == "Y" ] || [ "$answer" == "y" ]; then
		read -p "Enter the worker public ip : " WORKER_IP
		read -p "Enter the worker name : " WORKER_NAME
		echo -e "worker ansible_host=$WORKER_IP ansible_user=$WORKER_NAME" >> "$inven_path"
	else
		break
	fi
done

echo -e "\n[worker_node:vars]" >> "$inven_path"
echo -e "master_private_ip=$MASTER_PRIVATE_IP " >> "$inven_path"

# ansible-playbook 실행하여 cluster join하기
ansible-playbook -i "$inven_path" ansible_assets/k3s_worker_node_join.yaml