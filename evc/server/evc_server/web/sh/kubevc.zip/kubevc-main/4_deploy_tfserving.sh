#!/bin/bash

files=($HOME/.kube/*)
echo "Please select number from the cluster name list"
cluster_indices=()
cluster_index=0

for i in "${!files[@]}"; do
  if [[ ! "${files[$i]}" == *"/cache" ]]; then
    echo "$cluster_index. $(basename ${files[$i]})"
    cluster_indices+=("$i")
    ((cluster_index++))
  fi
done

while true; do
  read -p "> " choice

  if [ "$choice" -ge 0 ] && [ "$choice" -lt ${#cluster_indices[@]} ]; then
    selected_file=${files[ ${cluster_indices[$choice]} ]}
    selected_cluster_name=$(basename $selected_file)
    echo -e "[Selected Cluster]: $selected_cluster_name\n"
    export KUBECONFIG=$HOME/.kube/"$selected_cluster_name"
    break
  else
    echo -e "[Wrong Input]: Please try again\n"
  fi
done
echo -e "\n### Please configure the TensorFlow Serving Container. ###"
while true; do
  read -p "Number of replicas: " count_replicas
  if [ -z "$count_replicas" ]; then
    count_replicas=1
    break
  elif [[ "$count_replicas" =~ ^[0-9]+$ ]] && ! [[ "$count_replicas" -le 0 ]]; then
    break
  else
    echo "(Wrong Input. Please try again.)"
  fi
done

read -p "Ingress routing path(ex. /): " ingress_routing_path
if [ -z "$ingress_routing_path" ]; then
  ingress_routing_path="/"
elif ! [[ "$ingress_routing_path" == "/"* ]]; then
  ingress_routing_path="/$ingress_routing_path"
fi

read -p "Namespace: " Namespace_name
if [ -z "$Namespace_name" ]; then
  Namespace_name="tfserving"
fi

echo -e "\n[Creating] Namespace, Deployment, Service, Ingress in manifest.yaml"
if [[ $ingress_routing_path == "/" ]]; then
  cat <<EOF >/tmp/manifest.yaml
---
apiVersion: v1
kind: Namespace
metadata:
  name: $Namespace_name
---
apiVersion: apps/v1
kind: Deployment
metadata:
  namespace: $Namespace_name
  name: tensorflow-serving-deployment
spec:
  replicas: $count_replicas
  selector:
    matchLabels:
      app: tensorflow-serving
  template:
    metadata:
      labels:
        app: tensorflow-serving
    spec:
      containers:
        - name: tensorflow-serving
          image: kmubigdata/tfserving-armv8:latest
          ports:
            - containerPort: 8501
          volumeMounts:
            - name: model-volume
              mountPath: /models
          command: ["tensorflow_model_server"]
          args:
            - "--port=8500"
            - "--rest_api_port=8501"
            - "--model_config_file=/models/models.config"
            - "--model_config_file_poll_wait_seconds=60"
            - "--grpc_channel_arguments=grpc.max_send_message_length=50*1024*1024"
            - "--grpc_channel_arguments=grpc.max_receive_length=50*1024*1024"
            - "--grpc_max_threads=1000"
      volumes:
        - name: model-volume
          hostPath:
            path: /home/admin/models
---
apiVersion: v1
kind: Service
metadata:
  namespace: $Namespace_name
  name: tensorflow-serving-service
spec:
  type: ClusterIP
  selector:
    app: tensorflow-serving
  ports:
    - name: http
      protocol: TCP
      port: 8501
      targetPort: 8501
---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  namespace: $Namespace_name
  name: tensorflow-serving-ingress
spec:
  ingressClassName: nginx
  rules:
    - http:
        paths:
          - path: $ingress_routing_path
            pathType: ImplementationSpecific
            backend:
              service:
                name: tensorflow-serving-service
                port:
                  number: 8501
EOF
else
  cat <<EOF >/tmp/manifest.yaml
---
apiVersion: v1
kind: Namespace
metadata:
  name: $Namespace_name
---
apiVersion: apps/v1
kind: Deployment
metadata:
  namespace: $Namespace_name
  name: tensorflow-serving-deployment
spec:
  replicas: $count_replicas
  selector:
    matchLabels:
      app: tensorflow-serving
  template:
    metadata:
      labels:
        app: tensorflow-serving
    spec:
      containers:
        - name: tensorflow-serving
          image: kmubigdata/tfserving-armv8:latest
          ports:
            - containerPort: 8501
          volumeMounts:
            - name: model-volume
              mountPath: /models
          command: ["tensorflow_model_server"]
          args:
            - "--port=8500"
            - "--rest_api_port=8501"
            - "--model_config_file=/models/models.config"
            - "--model_config_file_poll_wait_seconds=60"
            - "--grpc_channel_arguments=grpc.max_send_message_length=50*1024*1024"
            - "--grpc_channel_arguments=grpc.max_receive_length=50*1024*1024"
            - "--grpc_max_threads=1000"
      volumes:
        - name: model-volume
          hostPath:
            path: /home/admin/models
---
apiVersion: v1
kind: Service
metadata:
  namespace: $Namespace_name
  name: tensorflow-serving-service
spec:
  type: ClusterIP
  selector:
    app: tensorflow-serving
  ports:
    - name: http
      protocol: TCP
      port: 8501
      targetPort: 8501
---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  namespace: $Namespace_name
  name: tensorflow-serving-ingress
  annotations:
    nginx.ingress.kubernetes.io/rewrite-target: /\$2
spec:
  ingressClassName: nginx
  rules:
    - http:
        paths:
          - path: $ingress_routing_path(/|$)(.*)
            pathType: ImplementationSpecific
            backend:
              service:
                name: tensorflow-serving-service
                port:
                  number: 8501
EOF
fi

echo -e "\n[Deploying] recources to the cluster"
kubectl apply -f /tmp/manifest.yaml > /dev/null

echo -e "\n\n### "The resources for tfserving were successfully deployed!" ###\n"