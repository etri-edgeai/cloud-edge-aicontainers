#!/bin/bash

# image classification TF/FP32 model (mobilenet v1)
# Unzip must be installed.
curl -O https://edge-inference.s3.us-west-2.amazonaws.com/CNN/model/mobilenet_v1/mobilenet_v1.zip
unzip -q mobilenet_v1.zip && rm mobilenet_v1.zip
mkdir -p ./mobilenet_v1/1
mv ./mobilenet_v1/* ./mobilenet_v1/1
