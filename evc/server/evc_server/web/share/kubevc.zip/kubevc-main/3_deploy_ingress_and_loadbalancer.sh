#!/bin/bash

NGINX_VERSION="v1.8.1"
METALLB_VERSION="v0.13.10"
LOADBALANCER_IP_POOL=""

# ingress controler
kubectl create -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/controller-$NGINX_VERSION/deploy/static/provider/baremetal/deploy.yaml


# enable strictARP and install MetalLB

kubectl get configmap kube-proxy -n kube-system -o yaml | sed -e "s/strictARP: false/strictARP: true/" | kubectl apply -f - -n kube-system
kubectl apply -f https://raw.githubusercontent.com/metallb/metallb/$METALLB_VERSION/config/manifests/metallb-native.yaml

echo ""
echo "Set loadbalancer's IP pool. The IP pool must be in the same network."
while true; do
  echo -n "Loadbalancer's IP(ex: 192.168.10.210-192.168.10.220) : " 
  read LOADBALANCER_IP_POOL

  break
done

# init manifest.yaml
cat << EOF > /tmp/manifest.yaml
---
apiVersion: metallb.io/v1beta1
kind: IPAddressPool
metadata:
  name: default
  namespace: metallb-system
spec:
  addresses:
  - $LOADBALANCER_IP_POOL
  autoAssign: true
---
apiVersion: metallb.io/v1beta1
kind: L2Advertisement
metadata:
  name: default
  namespace: metallb-system
spec:
  ipAddressPools:
    - default
---
EOF

kubectl delete validatingwebhookconfigurations metallb-webhook-configuration

kubectl create -f /tmp/manifest.yaml

# set ingress-controller type as LoadBalancer
kubectl -n ingress-nginx patch service ingress-nginx-controller -p '{"spec":{"type":"LoadBalancer"}}'
