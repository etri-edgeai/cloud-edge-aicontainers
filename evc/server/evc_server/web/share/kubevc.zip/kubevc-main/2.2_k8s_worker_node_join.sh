#!/bin/bash

inven_path="/tmp/inventory.txt"

read -p "Enter the Path of the SSH Key: " SSH_KEY_PATH
read -p "Enter the UserName of the Master node: " MASTER_USERNAME

while true; do
    read -p "Enter the IP Address of the Master node: " MASTER_IP

    if [ "$MASTER_IP" = "" ]; then
        break
    elif [[ $MASTER_IP =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
        IFS='.' read -r -a IP_BLOCKs <<< "$MASTER_IP"
        valid_ip=true
        for block in "${IP_BLOCKs[@]}"; do
            if [ "$block" -lt 0 ] || [ "$block" -gt 255 ]; then
                valid_ip=false
            fi
        done
        if $valid_ip; then
            echo "($MASTER_IP is valid IP address.)"
        break
        else
            echo "(Invalid IP address format. Please try again.)"
        fi
    else
        echo "(Invalid IP address format. Please try again.)"
    fi
done
if [ "$MASTER_IP" = "" ]; then
      LOCAL_IP_ADDRESS=`ip addr | grep global | head -n 1 | awk '{print $2}'`
      CLEANED_IP_ADDRESS=${LOCAL_IP_ADDRESS%%/*}
      MASTER_IP=$CLEANED_IP_ADDRESS
fi

echo -e "[all:vars]" > "$inven_path"
echo -e "ansible_ssh_private_key_file=$SSH_KEY_PATH" >> "$inven_path"
echo -e "ansible_ssh_common_args='-o StrictHostKeyChecking=no'" >> "$inven_path"

echo -e "\n[master_node]" >> "$inven_path"
echo -e "master ansible_host=$MASTER_IP ansible_user=$MASTER_USERNAME" >> "$inven_path"
echo -e "\n[master_node:vars]" >> "$inven_path"

echo -e "\n[worker_node]" >> "$inven_path"

while true; do
    read -p "Enter the UserName of the Worker node(If you want to quit, enter 0): " WORKER_USERNAME
    if [[ "$WORKER_USERNAME" == "0" ]]; then
        break
    fi
    read -p "Enter the Public IP Address of the Worker node: " WORKER_PUBLIC_IP
    echo -e "worker ansible_host=$WORKER_PUBLIC_IP ansible_user=$WORKER_USERNAME \n" >> "$inven_path"
done

echo -e "\n[worker_node:vars]" >> "$inven_path"

ansible-playbook -i "$inven_path" ansible_assets/worker_node_join.yml 