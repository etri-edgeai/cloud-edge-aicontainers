#!/bin/bash

read -p "Enter the number of replicas: " count_replicas
read -p "Enter the ingress routing path: " ingress_routing_path
read -p "Enter the Namespace: " Namespace_name

if [[ $ingress_routing_path == "/" ]]; then
  cat <<EOF >/tmp/manifest.yaml
---
apiVersion: v1
kind: Namespace
metadata:
  name: $Namespace_name
---
apiVersion: apps/v1
kind: Deployment
metadata:
  namespace: $Namespace_name
  name: tensorflow-serving-deployment
spec:
  replicas: $count_replicas
  selector:
    matchLabels:
      app: tensorflow-serving
  template:
    metadata:
      labels:
        app: tensorflow-serving
    spec:
      containers:
        - name: tensorflow-serving
          image: emacski/tensorflow-serving:latest
          ports:
            - containerPort: 8501
          volumeMounts:
            - name: model-volume
              mountPath: /models
          command: ["tensorflow_model_server"]
          args:
            - "--port=8500"
            - "--rest_api_port=8501"
            - "--model_config_file=/models/models.config"
            - "--model_config_file_poll_wait_seconds=60"
            - "--grpc_channel_arguments=grpc.max_send_message_length=50*1024*1024"
            - "--grpc_channel_arguments=grpc.max_receive_length=50*1024*1024"
            - "--grpc_max_threads=1000"
      volumes:
        - name: model-volume
          hostPath:
            path: /home/admin/models
---
apiVersion: v1
kind: Service
metadata:
  namespace: $Namespace_name
  name: tensorflow-serving-service
spec:
  type: ClusterIP
  selector:
    app: tensorflow-serving
  ports:
    - name: http
      protocol: TCP
      port: 8501
      targetPort: 8501
---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  namespace: $Namespace_name
  name: tensorflow-serving-ingress
spec:
  ingressClassName: nginx
  rules:
    - http:
        paths:
          - path: $ingress_routing_path
            pathType: ImplementationSpecific
            backend:
              service:
                name: tensorflow-serving-service
                port:
                  number: 8501
EOF
else
  cat <<EOF >/tmp/manifest.yaml
---
apiVersion: v1
kind: Namespace
metadata:
  name: $Namespace_name
---
apiVersion: apps/v1
kind: Deployment
metadata:
  namespace: $Namespace_name
  name: tensorflow-serving-deployment
spec:
  replicas: $count_replicas
  selector:
    matchLabels:
      app: tensorflow-serving
  template:
    metadata:
      labels:
        app: tensorflow-serving
    spec:
      containers:
        - name: tensorflow-serving
          image: emacski/tensorflow-serving:latest
          ports:
            - containerPort: 8501
          volumeMounts:
            - name: model-volume
              mountPath: /models
          command: ["tensorflow_model_server"]
          args:
            - "--port=8500"
            - "--rest_api_port=8501"
            - "--model_config_file=/models/models.config"
            - "--model_config_file_poll_wait_seconds=60"
            - "--grpc_channel_arguments=grpc.max_send_message_length=50*1024*1024"
            - "--grpc_channel_arguments=grpc.max_receive_length=50*1024*1024"
            - "--grpc_max_threads=1000"
      volumes:
        - name: model-volume
          hostPath:
            path: /home/admin/models
---
apiVersion: v1
kind: Service
metadata:
  namespace: $Namespace_name
  name: tensorflow-serving-service
spec:
  type: ClusterIP
  selector:
    app: tensorflow-serving
  ports:
    - name: http
      protocol: TCP
      port: 8501
      targetPort: 8501
---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  namespace: $Namespace_name
  name: tensorflow-serving-ingress
  annotations:
    nginx.ingress.kubernetes.io/rewrite-target: /\$2
spec:
  ingressClassName: nginx
  rules:
    - http:
        paths:
          - path: $ingress_routing_path(/|$)(.*)
            pathType: ImplementationSpecific
            backend:
              service:
                name: tensorflow-serving-service
                port:
                  number: 8501
EOF
fi

kubectl apply -f /tmp/manifest.yaml