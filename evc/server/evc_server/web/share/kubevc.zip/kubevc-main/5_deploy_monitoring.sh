#!/bin/bash

# add kube-prometheus helm repo
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo update

echo "Enter Grafana admin password. It will set 'admin' if blank. "
echo -n "Password : "
read PASSWORD
if [ "$PASSWORD" = "" ]; then
    PASSWORD="admin"
fi
echo "Enter password : $PASSWORD"

echo "Enter ingress path. (ex: /monitor)"
echo -n "Ingress path : "
read INGRESS_PATH
if [ "$INGRESS_PATH" = "" ]; then
    INGRESS_PATH="/monitor"
fi

echo "Enter ingress virtualhost. It could be domain or wildcard(* or blank). (ex: $INGRESS_HOST_HINT)"
echo -n "Ingress virtual host : "
read INGRESS_HOST

helm inspect values prometheus-community/kube-prometheus-stack > /tmp/kube-prometheus-stack.values
if [[ "$INGRESS_HOST" = "" || "$INGRESS_HOST" = "*" ]]; then
    helm install prometheus-community/kube-prometheus-stack \
        --create-namespace --namespace monitoring \
        --generate-name --values /tmp/kube-prometheus-stack.values \
        --set grafana.adminPassword=$PASSWORD\
        --set grafana.ingress.enabled=true \
        --set grafana.ingress.ingressClassName=nginx \
        --set grafana.ingress.paths={$INGRESS_PATH} \
        --set prometheus.prometheusSpec.serviceMonitorSelectorNilUsesHelmValues=false \
        --set prometheus.prometheusSpec.podMonitorSelectorNilUsesHelmValues=false
else
    helm install prometheus-community/kube-prometheus-stack \
        --create-namespace --namespace monitoring \
        --generate-name --values /tmp/kube-prometheus-stack.values \
        --set grafana.adminPassword=$PASSWORD\
        --set grafana.ingress.enabled=true \
        --set grafana.ingress.ingressClassName=nginx \
        --set grafana.ingress.paths={$INGRESS_PATH} \
        --set grafana.ingress.hosts={$INGRESS_HOST} \
        --set prometheus.prometheusSpec.serviceMonitorSelectorNilUsesHelmValues=false \
        --set prometheus.prometheusSpec.podMonitorSelectorNilUsesHelmValues=false
fi