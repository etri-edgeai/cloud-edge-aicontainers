#!/bin/bash

echo -e "[all:vars]\n" > /tmp/inventory.txt
read -p "Enter the Path of the SSH Key: " SSH_KEY_PATH
echo -e "ansible_ssh_private_key_file=$SSH_KEY_PATH \n" >> /tmp/inventory.txt
echo -e "ansible_ssh_common_args='-o StrictHostKeyChecking=no' \n" >> /tmp/inventory.txt

echo -e "[master:vars]\n" >> /tmp/inventory.txt
read -p "Enter the UserName of the Master node: " MASTER_USERNAME
echo -e "ansible_user=$MASTER_USERNAME \n" >> /tmp/inventory.txt

echo -e "[master]\n" >> /tmp/inventory.txt
while true; do
    read -p "Enter the Public IP Address of the Master node: " MASTER_PUBLIC_IP

    if [ "$MASTER_PUBLIC_IP" = "" ]; then
        break
    elif [[ $MASTER_PUBLIC_IP =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
        IFS='.' read -r -a IP_BLOCKs <<< "$MASTER_PUBLIC_IP"
        valid_ip=true
        for block in "${IP_BLOCKs[@]}"; do
            if [ "$block" -lt 0 ] || [ "$block" -gt 255 ]; then
                valid_ip=false
            fi
        done
        if $valid_ip; then
            echo "($MASTER_PUBLIC_IP is valid IP address.)"
        break
        else
            echo "(Invalid IP address format. Please try again.)"
        fi
    else
        echo "(Invalid IP address format. Please try again.)"
    fi
done
if [ "$MASTER_PUBLIC_IP" = "" ]; then
      LOCAL_IP_ADDRESS=`ip addr | grep global | head -n 1 | awk '{print $2}'`
      CLEANED_IP_ADDRESS=${LOCAL_IP_ADDRESS%%/*}
      MASTER_PUBLIC_IP=$CLEANED_IP_ADDRESS
fi
echo -e "$MASTER_PUBLIC_IP \n" >> /tmp/inventory.txt

echo -e "[children:vars]\n" >> /tmp/inventory.txt
echo -e "ansible_user=localhost \n" >> /tmp/inventory.txt
echo -e "[children]\n" >> /tmp/inventory.txt
echo -e "127.0.0.1 \n" >> /tmp/inventory.txt

echo -e "\n\n### Please enter the information of your cluster ###"

read -p "K8S cluster name: " CLUSTER_NAME
if [ "$CLUSTER_NAME" = "" ]; then
    CLUSTER_NAME="kubernetes"
fi
read -p "Cluster IP range as CIDR: " CLUSTER_CIDR
if [ "$CLUSTER_CIDR" = "" ]; then
    CLUSTER_CIDR="172.17.0.0/16"
fi

ansible-playbook -i /tmp/inventory.txt ansible_assets/cluster_init.yml -e "MASTER_PUBLIC_IP=$MASTER_PUBLIC_IP" -e "CLUSTER_NAME=$CLUSTER_NAME" -e "CLUSTER_CIDR=$CLUSTER_CIDR"
echo -e "\n\n### K8S Cluster was successfully initialized! ###"
rm /tmp/inventory.txt

#Download .kube/config file from master node
mkdir -p ~/.kube
LOCAL_PATH="$HOME/.kube"
scp -i "$SSH_KEY_PATH" ubuntu@"$MASTER_PUBLIC_IP":/tmp/config "$LOCAL_PATH"

echo -e "\n\n### "Download of config file from the master node was complete!" ###"
